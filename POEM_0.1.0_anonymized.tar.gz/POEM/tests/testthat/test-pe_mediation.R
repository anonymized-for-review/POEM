# Extract one value from a poem_tbl result by term name.
v <- function(tab, t) tab$value[tab$term == t]

test_that("the output has the documented schema and a numeric value column", {
  set.seed(113)
  d <- simulate_mediation_data(n = 120, p = 50, outcome = "continuous",
                               pattern = "homogeneous", c1 = 0.6)
  fit <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous")
  expect_s3_class(fit, "poem_tbl")
  expect_true(is.numeric(fit$value))
  expect_true(all(c("stat_hdmm", "pval_hdmm", "stat_pe", "j_pe", "pval_pe",
                    "total_indirect_effect", "n_active_mediators", "df",
                    "n_candidate_mediators", "n_observations") %in% fit$term))
  expect_equal(v(fit, "df"), 1)
  expect_equal(v(fit, "n_candidate_mediators"), 50)
  expect_equal(v(fit, "n_observations"), 120)
})

test_that("M_PE = S_n + J_m and the p-value is the chi-square upper tail", {
  set.seed(113)
  d <- simulate_mediation_data(n = 120, p = 50, outcome = "continuous",
                               pattern = "contrasting", c1 = 0.6)
  fit <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous")
  # The power-enhanced statistic is exactly the Wald statistic plus the PE
  # component; this is the defining identity of the method.
  expect_equal(v(fit, "stat_pe"), v(fit, "stat_hdmm") + v(fit, "j_pe"))
  expect_equal(v(fit, "pval_pe"),
               pchisq(v(fit, "stat_pe"), df = v(fit, "df"), lower.tail = FALSE))
  expect_equal(v(fit, "pval_hdmm"),
               pchisq(v(fit, "stat_hdmm"), df = v(fit, "df"), lower.tail = FALSE))
})

test_that("the front end dispatches identically to the workers", {
  set.seed(113)
  d <- simulate_mediation_data(n = 120, p = 50, outcome = "continuous",
                               pattern = "homogeneous", c1 = 0.6)
  a <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous")
  b <- pe_mediation_linear(d$X, d$Y, d$M)
  expect_identical(a$value, b$value)
  expect_identical(attr(a, "active_mediators"), attr(b, "active_mediators"))
})

test_that("the PE test is never less significant than the Wald test (deterministic)", {
  set.seed(113)
  d <- simulate_mediation_data(n = 120, p = 50, outcome = "continuous",
                               pattern = "homogeneous", c1 = 0.6)
  fit <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous")
  # Because M_PE = S_n + J_m with J_m >= 0, the PE p-value is always at most
  # the Wald p-value; this holds for every data set, not just on average.
  expect_lte(v(fit, "pval_pe"), v(fit, "pval_hdmm"))
})

test_that("power enhancement detects contrasting mediation that the Wald test misses", {
  set.seed(113)
  # A strong contrasting signal where the total indirect effect is exactly
  # zero, so the benchmark test has essentially no power but the PE test does.
  d <- simulate_mediation_data(n = 200, p = 60, outcome = "continuous",
                               pattern = "contrasting", c1 = 1.0)
  expect_lt(abs(d$beta), 1e-8)
  fit <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous")
  expect_gt(v(fit, "pval_hdmm"), 0.05)        # Wald test does not reject
  expect_lt(v(fit, "pval_pe"), 0.01)          # PE test rejects decisively
  expect_gt(v(fit, "n_active_mediators"), 0)  # and names active mediators
})

test_that("j_pe is nonnegative and stat_pe is at least stat_hdmm", {
  set.seed(113)
  d <- simulate_mediation_data(n = 120, p = 50, outcome = "count",
                               pattern = "homogeneous", c1 = 0.4, c2 = 0.4)
  fit <- pe_mediation(d$X, d$Y, d$M, outcome = "count")
  expect_gte(v(fit, "j_pe"), 0)
  expect_gte(v(fit, "stat_pe"), v(fit, "stat_hdmm"))
})

test_that("input validation rejects malformed arguments", {
  set.seed(113)
  d <- simulate_mediation_data(n = 80, p = 40, outcome = "continuous",
                               pattern = "homogeneous")
  expect_error(pe_mediation(d$X, d$Y[-1], d$M, outcome = "continuous"),
               "same number of rows")
  expect_error(pe_mediation(d$X, d$Y, d$M, outcome = "continuous",
                            error_level = 0), "in \\(0, 1\\)")
  expect_error(pe_mediation(d$X, d$Y, d$M, outcome = "continuous",
                            error_level = 1.5), "in \\(0, 1\\)")
  expect_error(pe_mediation_linear(d$X, d$Y, d$M, lambda_grid = c(-1, 1)),
               "> 0")
  # A binary outcome routed to the linear worker should be rejected.
  expect_error(pe_mediation(d$X, rbinom(length(d$Y), 1, 0.5), d$M,
                            outcome = "continuous"), "binary")
})

test_that("the three multiplicity methods all run and preserve the identity", {
  set.seed(113)
  d <- simulate_mediation_data(n = 150, p = 60, outcome = "continuous",
                               pattern = "contrasting", c1 = 0.6)
  for (m in c("Bonferroni", "BH", "BY")) {
    fit <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous", method = m)
    expect_equal(v(fit, "stat_pe"), v(fit, "stat_hdmm") + v(fit, "j_pe"),
                 info = m)
  }
})
