test_that("the power curve returns the documented structure", {
  set.seed(113)
  pc <- pe_power_curve(n = 80, p = 30, outcome = "continuous",
                       pattern = "contrasting", c1_grid = c(0, 0.6),
                       n_rep = 8)
  expect_s3_class(pc, "poem_tbl")
  expect_equal(nrow(pc), 2L)
  expect_true(all(c("c1", "rejection_hdmm", "rejection_pe", "n_valid") %in%
                    names(pc)))
  # Rejection rates are proportions in [0, 1].
  expect_true(all(pc$rejection_hdmm >= 0 & pc$rejection_hdmm <= 1))
  expect_true(all(pc$rejection_pe >= 0 & pc$rejection_pe <= 1))
})

test_that("under contrasting mediation the PE test out-rejects the Wald test as c1 grows", {
  skip_on_cran()
  set.seed(113)
  pc <- pe_power_curve(n = 120, p = 50, outcome = "continuous",
                       pattern = "contrasting", c1_grid = c(0, 0.8),
                       n_rep = 40)
  null_row <- pc[pc$c1 == 0, ]
  alt_row  <- pc[pc$c1 == 0.8, ]
  # Size: both tests are near nominal under the global null (generous band).
  expect_lt(null_row$rejection_pe, 0.2)
  # Power: the PE test rejects far more often than the Wald test under the
  # contrasting alternative, which is the article's headline result.
  expect_gt(alt_row$rejection_pe, alt_row$rejection_hdmm + 0.3)
})

test_that("the power curve validates alpha", {
  expect_error(pe_power_curve(n = 50, p = 20, c1_grid = 0, n_rep = 2,
                              alpha = 0), "in \\(0, 1\\)")
})
