## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7,
                      fig.height = 4.2)
library(POEM)
set.seed(113)

## ----blind-spot---------------------------------------------------------------
homo <- simulate_mediation_data(n = 200, p = 80, outcome = "continuous",
                                pattern = "homogeneous", c1 = 0.5)
cont <- simulate_mediation_data(n = 200, p = 80, outcome = "continuous",
                                pattern = "contrasting", c1 = 0.5)

verdict <- function(d) {
  f <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous")
  c(HDMM = f$value[f$term == "pval_hdmm"], PE = f$value[f$term == "pval_pe"])
}
round(rbind(homogeneous = verdict(homo), contrasting = verdict(cont)), 4)

## ----size---------------------------------------------------------------------
size <- pe_power_curve(n = 150, p = 50, outcome = "continuous",
                       pattern = "contrasting", c1_grid = 0, n_rep = 60)
size[, c("rejection_hdmm", "rejection_pe")]

## ----draw-helper--------------------------------------------------------------
draw <- function(pc, main) {
  plot(pc$c1, pc$rejection_pe, type = "b", pch = 19, ylim = c(0, 1),
       xlab = expression(c[1]), ylab = "rejection rate", main = main)
  lines(pc$c1, pc$rejection_hdmm, type = "b", pch = 1, lty = 2)
  abline(h = 0.05, col = "grey60", lty = 3)
  legend("topleft", c("PE", "HDMM"), pch = c(19, 1), lty = c(1, 2), bty = "n")
}
grid <- c(0, 0.25, 0.5, 0.75, 1)

## ----dominate, fig.height = 4, fig.alt = "Rejection-rate curves showing PE dominating HDMM under fully-cancelling and partially-cancelling heterogeneous mediation"----
p <- 50
# Mixed-sign mediators that only partially cancel: a small but nonzero total
# indirect effect, where the benchmark is weak and the enhancement is not.
alpha_mix <- c(1, -0.9, 0.8, -0.7, 0.6, -0.5, rep(0, p - 6))
tau_mix   <- c(rep(0.3, 6), rep(0, p - 6))

pc_cancel <- pe_power_curve(n = 150, p = p, outcome = "continuous",
                            pattern = "contrasting", c1_grid = grid, n_rep = 30)
pc_mixed  <- pe_power_curve(n = 150, p = p, outcome = "continuous",
                            c1_grid = grid, n_rep = 30,
                            outcome_args = list(alpha_m = alpha_mix, tau = tau_mix))

op <- par(mfrow = c(1, 2))
draw(pc_cancel, "fully cancelling")
draw(pc_mixed, "partially cancelling")
par(op)

## ----homo-curve, fig.height = 4, fig.width = 4.2, fig.alt = "Rejection-rate curves under homogeneous mediation, where HDMM and PE nearly coincide"----
pc_homo <- pe_power_curve(n = 150, p = p, outcome = "continuous",
                          pattern = "homogeneous", c1_grid = grid, n_rep = 30)
draw(pc_homo, "homogeneous")

## ----cross-outcome------------------------------------------------------------
at_c1 <- function(outcome, c2) {
  pc <- pe_power_curve(n = 180, p = 50, outcome = outcome,
                       pattern = "contrasting", c1_grid = 1, c2 = c2,
                       n_rep = 20)
  c(HDMM = pc$rejection_hdmm, PE = pc$rejection_pe)
}
round(rbind(continuous = at_c1("continuous", 0.5),
            binary     = at_c1("binary", 1),
            count      = at_c1("count", 0.4)), 3)

## ----identification-----------------------------------------------------------
pe_identification_study(n = 150, p = 60, outcome = "continuous",
                        pattern = "contrasting", c1_grid = c(0, 1),
                        n_rep = 30, methods = "Bonferroni")

## ----who----------------------------------------------------------------------
imr <- WHO_mediation_analysis("imr", groupings = c("global", "region", "income"),
                              lambda_grid = seq(0.1, 5, length.out = 100))
summary(imr)

## ----external, eval = FALSE---------------------------------------------------
# d <- simulate_mediation_data(n = 300, p = 500, outcome = "continuous",
#                              pattern = "contrasting", c1 = 0.5)
# pe <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous")
# 
# # HILMA (package 'freebird'): a debiased-lasso total-mediation-effect test.
# hilma_p <- freebird::hilma(d$Y, d$M, d$X)$pvalue
# 
# # GlobalTest (Bioconductor package 'globaltest'): a score test of the
# # mediator block against the outcome.
# gt_p <- globaltest::p.value(globaltest::gt(d$Y, d$M))
# 
# data.frame(method = c("HDMM", "PE-HDMM", "HILMA", "GlobalTest"),
#            pval = c(pe$value[pe$term == "pval_hdmm"],
#                     pe$value[pe$term == "pval_pe"], hilma_p, gt_p))

