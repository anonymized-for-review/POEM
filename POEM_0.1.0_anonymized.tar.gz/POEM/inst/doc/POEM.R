## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7,
                      fig.height = 4.2)
library(POEM)

## ----sim----------------------------------------------------------------------
set.seed(113)
d <- simulate_mediation_data(n = 200, p = 60, outcome = "continuous",
                             pattern = "contrasting", c1 = 1)

## ----sim-pieces---------------------------------------------------------------
dim(d$X)   # exposure: 200 observations, 1 column
length(d$Y)   # outcome: 200 values
dim(d$M)   # mediators: 200 x 60
d$active_mediators   # which mediators are truly active (the ground truth)
d$beta               # the total indirect effect: zero, by construction

## ----first-fit----------------------------------------------------------------
fit <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous")
fit

## ----read---------------------------------------------------------------------
fit$value[fit$term == "pval_pe"]            # the exact p-value
attr(fit, "active_mediators")               # the active mediator indices

## ----methods------------------------------------------------------------------
des_idx <- function(f) attr(f, "active_mediators")
des_idx(pe_mediation(d$X, d$Y, d$M, outcome = "continuous", method = "Bonferroni"))
des_idx(pe_mediation(d$X, d$Y, d$M, outcome = "continuous", method = "BH"))

## ----glm----------------------------------------------------------------------
set.seed(113)
db <- simulate_mediation_data(n = 250, p = 50, outcome = "binary",
                              pattern = "contrasting", c1 = 1, c2 = 1)
pe_mediation(db$X, db$Y, db$M, outcome = "binary")

## ----power, fig.alt = "Rejection-rate curves for the benchmark and power-enhanced tests"----
set.seed(113)
pc <- pe_power_curve(n = 150, p = 50, outcome = "continuous",
                     pattern = "contrasting", c1_grid = c(0, 0.25, 0.5, 0.75, 1),
                     n_rep = 40)
pc

plot(pc$c1, pc$rejection_pe, type = "b", pch = 19, ylim = c(0, 1),
     xlab = expression(c[1] * " (signal strength)"),
     ylab = "empirical rejection rate",
     main = "Contrasting mediation: PE vs. benchmark")
lines(pc$c1, pc$rejection_hdmm, type = "b", pch = 1, lty = 2)
abline(h = 0.05, col = "grey60", lty = 3)
legend("right", c("power-enhanced", "benchmark Wald"), pch = c(19, 1),
       lty = c(1, 2), bty = "n")

## ----who-data-----------------------------------------------------------------
data(WHO_health_mediation)
dim(WHO_health_mediation)
WHO_health_mediation[1:3, c("country", "region", "income", "year",
                            "gdp_growth", "imr", "gge_gdp")]

## ----codebook-----------------------------------------------------------------
head(WHO_indicator_codebook, 4)

## ----who-design---------------------------------------------------------------
des <- WHO_mediation_design("imr")          # infant mortality rate
c(observations = des$n, mediators = ncol(des$M), confounders = ncol(des$Z))

fit <- pe_mediation(des$X, des$Y, des$M, Z = des$Z, outcome = "continuous",
                    lambda_grid = seq(0.1, 5, length.out = 100))
active <- des$indicators[attr(fit, "active_mediators")]
WHO_indicator_codebook$description[
  match(active, WHO_indicator_codebook$indicator)]

## ----who-analysis-------------------------------------------------------------
res <- WHO_mediation_analysis("imr", groupings = c("global", "region"),
                              lambda_grid = seq(0.1, 10, length.out = 40))
res[, c("group", "n_countries", "pval_hdmm", "pval_pe", "active_mediators")]

## ----who-summary--------------------------------------------------------------
summary(res)

## ----who-exact, eval = FALSE--------------------------------------------------
# pe_mediation(scale(des$X), des$Y - mean(des$Y), scale(des$M), Z = des$Z,
#              outcome = "continuous", scale = FALSE,
#              lambda_grid = seq(0.1, 5, length.out = 100))

## ----formula------------------------------------------------------------------
set.seed(113)
d <- simulate_mediation_data(n = 200, p = 60, outcome = "continuous",
                             pattern = "contrasting", c1 = 1)
df <- data.frame(y = d$Y, x = d$X[, 1], d$M)
meds <- grep("^X", names(df), value = TRUE)   # the mediator columns
fit <- pe_mediate(y ~ x, data = df, mediators = meds, outcome = "continuous")

## ----mediators----------------------------------------------------------------
pe_mediators(fit)

## ----plot-mediators, fig.alt = "Per-mediator screening evidence for the selected candidate mediators"----
plot(fit)

## ----broom--------------------------------------------------------------------
generics::glance(fit)

## ----selection----------------------------------------------------------------
fit_all <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous",
                        report_all_methods = TRUE)
pe_selection(fit_all)

## ----ssplan, eval = FALSE-----------------------------------------------------
# plan <- ss_power_pe_mediation(outcome = "continuous", pattern = "contrasting",
#                               p = 50, n_grid = c(80, 120, 160, 200),
#                               target_power = 0.8, n_rep = 100)
# plan
# attr(plan, "recommended_n")

