## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7,
                      fig.height = 4.2)
library(POEM)

## ----seed---------------------------------------------------------------------
set.seed(113)

## ----plot-helper--------------------------------------------------------------
plot_rejection <- function(pc, main) {
  plot(pc$c1, pc$rejection_pe, type = "b", pch = 19, ylim = c(0, 1),
       xlab = expression(c[1] * "  (signal strength)"),
       ylab = "empirical rejection rate", main = main)
  lines(pc$c1, pc$rejection_hdmm, type = "b", pch = 1, lty = 2)
  abline(h = 0.05, col = "grey60", lty = 3)
  legend("right", c("PE (proposed)", "HDMM (benchmark)"),
         pch = c(19, 1), lty = c(1, 2), bty = "n")
}

## ----lm-curves, fig.height = 4, fig.alt = "Reduced reproduction of the manuscript's linear-model rejection-rate figure for the homogeneous and contrasting settings"----
set.seed(113)
lm_homo <- pe_power_curve(n = 150, p = 50, outcome = "continuous",
                          pattern = "homogeneous",
                          c1_grid = c(0, 0.25, 0.5, 0.75, 1),
                          c2 = 0.5, n_rep = 25)
lm_cont <- pe_power_curve(n = 150, p = 50, outcome = "continuous",
                          pattern = "contrasting",
                          c1_grid = c(0, 0.25, 0.5, 0.75, 1),
                          c2 = 0.5, n_rep = 25)

op <- par(mfrow = c(1, 2))
plot_rejection(lm_homo, "(i) homogeneous")
plot_rejection(lm_cont, "(ii) contrasting")
par(op)

## ----lm-paper-scale, eval = FALSE---------------------------------------------
# c1_grid <- seq(-1, 1, by = 0.1)
# lm_homo_full <- pe_power_curve(n = 300, p = 500, outcome = "continuous",
#                                pattern = "homogeneous", c1_grid = c1_grid,
#                                c2 = 0.5, n_rep = 1000, cores = 4)
# lm_cont_full <- pe_power_curve(n = 300, p = 500, outcome = "continuous",
#                                pattern = "contrasting", c1_grid = c1_grid,
#                                c2 = 0.5, n_rep = 1000, cores = 4)

## ----lm-study, eval = FALSE---------------------------------------------------
# study <- pe_simulation_study(n = 300, p = 500, outcome = "continuous",
#                              patterns = c("homogeneous", "contrasting"),
#                              c1_grid = seq(-1, 1, by = 0.1), n_rep = 1000)

## ----guo-data-----------------------------------------------------------------
d <- simulate_guo_mediation(c1 = 1, seed = 113)
dim(d$M)                              # 85 x 1008, the case-study dimensions
d$active_mediators                    # the 11 active loci
round(d$beta, 4)                      # beta_per_c1 * c1, i.e. about -1.597

## ----guo-fit------------------------------------------------------------------
dn <- simulate_guo_mediation(c1 = 1, n = 150, seed = 113)
fit <- pe_mediation(dn$X, dn$Y, dn$M, outcome = "continuous",
                    lambda_grid = seq(0.1, 10, length.out = 50))
fit[fit$term %in% c("pval_hdmm", "pval_pe", "n_active_mediators"), ]

## ----guo-paper-scale, eval = FALSE--------------------------------------------
# rej <- function(c1, confounders) {
#   ps <- replicate(1000, {
#     d <- simulate_guo_mediation(c1 = c1, confounders = confounders)
#     f <- pe_mediation(d$X, d$Y, d$M, Z = d$Z, outcome = "continuous",
#                       lambda_grid = seq(0.1, 10, length.out = 50))
#     c(f$value[f$term == "pval_hdmm"], f$value[f$term == "pval_pe"])
#   })
#   rowMeans(ps <= 0.05)
# }
# sapply(seq(-1, 1, by = 0.1), rej, confounders = FALSE)

## ----glm-curves, fig.height = 4, fig.alt = "Reduced reproduction of the manuscript's logistic and Poisson rejection-rate figures under the contrasting setting"----
set.seed(113)
logit_cont <- pe_power_curve(n = 180, p = 50, outcome = "binary",
                             pattern = "contrasting",
                             c1_grid = c(0, 0.25, 0.5, 0.75, 1),
                             c2 = 1, n_rep = 20)
pois_cont <- pe_power_curve(n = 180, p = 50, outcome = "count",
                            pattern = "contrasting",
                            c1_grid = c(0, 0.25, 0.5, 0.75, 1),
                            c2 = 0.4, n_rep = 20)

op <- par(mfrow = c(1, 2))
plot_rejection(logit_cont, "Logistic, contrasting")
plot_rejection(pois_cont, "Poisson, contrasting")
par(op)

## ----glm-paper-scale, eval = FALSE--------------------------------------------
# c1_grid <- seq(-1, 1, by = 0.1)
# # Logistic: c2 = 1
# for (pat in c("homogeneous", "contrasting"))
#   pe_power_curve(n = 300, p = 500, outcome = "binary", pattern = pat,
#                  c1_grid = c1_grid, c2 = 1, n_rep = 1000, cores = 4)
# # Poisson: c2 = 0.4
# for (pat in c("homogeneous", "contrasting"))
#   pe_power_curve(n = 300, p = 500, outcome = "count", pattern = pat,
#                  c1_grid = c1_grid, c2 = 0.4, n_rep = 1000, cores = 4)

## ----identification-----------------------------------------------------------
set.seed(113)
d <- simulate_mediation_data(n = 200, p = 60, outcome = "continuous",
                             pattern = "contrasting", c1 = 1)
d$active_mediators                                  # ground truth

fit_all <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous",
                        report_all_methods = TRUE)
pe_selection(fit_all)                               # per-method sets + p-values

## ----id-study-----------------------------------------------------------------
set.seed(113)
pe_identification_study(n = 150, p = 60, outcome = "continuous",
                        pattern = "contrasting", c1_grid = c(0, 0.5, 1),
                        n_rep = 30)

## ----id-study-paper, eval = FALSE---------------------------------------------
# pe_identification_study(n = 300, p = 500, outcome = "continuous",
#                         pattern = "contrasting", c1_grid = seq(0, 1, by = 0.1),
#                         n_rep = 1000, cores = 4)

## ----who-data-----------------------------------------------------------------
data(WHO_health_mediation)
dim(WHO_health_mediation)
table(WHO_health_mediation$region)

## ----who-imr------------------------------------------------------------------
imr <- WHO_mediation_analysis("imr", groupings = c("global", "region", "income"))
imr[, c("group", "n_countries", "pval_hdmm", "pval_pe", "active_mediators")]

## ----who-summary--------------------------------------------------------------
summary(imr)

## ----who-full-----------------------------------------------------------------
WHO_mediation_analysis("imr", groupings = "global", full_table = TRUE)

## ----who-others, eval = FALSE-------------------------------------------------
# for (y in c("u5mr", "leb", "lbw", "pou"))
#   print(WHO_mediation_analysis(y, groupings = c("global", "region", "income")))

## ----who-cell, warning = FALSE------------------------------------------------
cell <- WHO_mediation_design("imr", region = "AFR", income = "Upper-middle")
c(n_countries= cell$n_countries, mediators = ncol(cell$M))

keep <- apply(cell$M, 2L, sd) > 0
fit <- tryCatch(
  pe_mediation(scale(cell$X), cell$Y - mean(cell$Y),
               scale(cell$M[, keep, drop = FALSE]),
               Z = cell$Z, outcome = "continuous", scale = FALSE,
               lambda_grid = seq(0.1, 5, length.out = 100)),
  error = function(e) NULL)
if (is.null(fit)) "singular covariance (cell too small)" else
  cell$indicators[keep][attr(fit, "active_mediators")]

## ----who-screen---------------------------------------------------------------
des <- WHO_mediation_design("imr")                  # global IMR design
gfit <- pe_mediation(scale(des$X), des$Y - mean(des$Y), scale(des$M),
                     Z = des$Z, outcome = "continuous", scale = FALSE,
                     lambda_grid = seq(0.1, 5, length.out = 100))
pe_mediators(gfit)

