#' Simulation-based sample size planning for the power-enhanced mediation test
#'
#' Estimates, by Monte Carlo simulation, the sample size needed for the
#' power-enhanced test to reach a target power under a given mediation
#' pattern and signal strength. It evaluates the empirical power of the PE
#' test (and, for comparison, the benchmark Wald test) at each candidate
#' sample size on a grid, and reports the smallest grid value that reaches
#' the target. This is the design counterpart of the analysis function
#' [pe_mediation()]: use it to plan a study, then [pe_mediation()] to
#' analyze it.
#'
#' @details
#' This is a simulation-based procedure, not a closed-form power formula:
#' no analytic power expression exists for the PE test, so sample size is
#' instead determined by direct Monte Carlo simulation. Power is estimated
#' by simulating `n_rep` data sets at each candidate
#' `n` with [simulate_mediation_data()] and recording how often the test
#' rejects at level `alpha`. Because the estimate is a Monte Carlo
#' proportion, it carries simulation error of roughly
#' \eqn{\sqrt{power(1 - power) / n\_rep}}; raise `n_rep` for a smoother
#' curve and a more stable recommendation. The grid approach (rather than
#' a root search) is deliberate: the power curve is monotone but noisy, so
#' a search can stop early on a lucky draw, whereas the grid shows the
#' whole trajectory.
#'
#' @param outcome Outcome type: `"continuous"`, `"binary"`, or `"count"`.
#' @param pattern Mediation pattern: `"homogeneous"` or `"contrasting"`
#'   (`"heterogeneous"` is a synonym for `"contrasting"`).
#' @param p Number of candidate mediators.
#' @param n_grid Vector of candidate sample sizes to evaluate.
#' @param c1 Signal strength (the exposure-on-mediator scale). Default 1.
#' @param c2 Direct effect. Default 0.5.
#' @param target_power Desired power for the PE test. Default 0.8.
#' @param n_rep Monte Carlo replications per candidate `n`. Default 200.
#' @param alpha Significance level. Default 0.05.
#' @param method,error_level Passed to [pe_mediation()].
#' @param cores Number of CPU cores (Unix forking). Default 1.
#' @param seed Optional integer seed, set locally and restored on exit.
#'
#' @return A tidy `data.frame` (class `poem_tbl`) with one row per
#'   candidate sample size and columns `n`, `power_pe`, `power_hdmm`, and
#'   `n_valid`. The smallest `n` reaching `target_power` for the PE test is
#'   stored in the `"recommended_n"` attribute (`NA` if no grid value
#'   reaches it).
#'
#' @author Anonymous
#'
#' @seealso [pe_power_curve()], [pe_mediation()],
#'   [simulate_mediation_data()].
#'
#' @family mediation simulation
#'
#' @examples
#' \donttest{
#' set.seed(113)
#' plan <- ss_power_pe_mediation(outcome = "continuous", pattern = "contrasting",
#'                               p = 50, n_grid = c(80, 120, 160), n_rep = 30)
#' plan
#' attr(plan, "recommended_n")
#' }
#'
#' @export
ss_power_pe_mediation <- function(outcome = c("continuous", "binary", "count"),
                                  pattern = c("homogeneous", "contrasting",
                                              "heterogeneous"),
                                  p, n_grid, c1 = 1, c2 = 0.5,
                                  target_power = 0.8, n_rep = 200, alpha = 0.05,
                                  method = c("Bonferroni", "BH", "BY"),
                                  error_level = 0.05, cores = 1L, seed = NULL) {
  outcome <- match.arg(outcome)
  pattern <- match.arg(pattern)
  method <- match.arg(method)
  if (!is.numeric(n_grid) || length(n_grid) < 1L || any(n_grid < 10))
    stop("`n_grid` must be a vector of sample sizes (each >= 10).",
         call. = FALSE)
  if (!is.numeric(target_power) || length(target_power) != 1L ||
      target_power <= 0 || target_power >= 1)
    stop("`target_power` must be a single number in (0, 1).", call. = FALSE)

  if (!is.null(seed)) {
    if (exists(".Random.seed", envir = globalenv())) {
      old <- get(".Random.seed", envir = globalenv())
      on.exit(assign(".Random.seed", old, envir = globalenv()), add = TRUE)
    } else {
      on.exit(if (exists(".Random.seed", envir = globalenv()))
        rm(".Random.seed", envir = globalenv()), add = TRUE)
    }
    set.seed(seed)
  }

  # Evaluate power at each candidate n by reusing the single-point power curve
  # (c1 fixed); the c1 = 0 size case is not needed here, so the grid is one c1.
  n_grid <- sort(unique(as.integer(n_grid)))
  rows <- lapply(n_grid, function(nn) {
    pc <- pe_power_curve(n = nn, p = p, outcome = outcome, pattern = pattern,
                         c1_grid = c1, c2 = c2, n_rep = n_rep, alpha = alpha,
                         method = method, error_level = error_level,
                         cores = cores)
    data.frame(n = nn, power_pe = pc$rejection_pe[1],
               power_hdmm = pc$rejection_hdmm[1], n_valid = pc$n_valid[1],
               stringsAsFactors = FALSE)
  })
  out <- do.call(rbind, rows)

  # Recommended n: the smallest grid value whose PE power reaches the target.
  reached <- which(out$power_pe >= target_power)
  recommended_n <- if (length(reached)) out$n[min(reached)] else NA_integer_

  out <- .as_poem_tbl(out)
  attr(out, "recommended_n") <- recommended_n
  attr(out, "target_power")  <- target_power
  attr(out, "outcome")       <- outcome
  attr(out, "pattern")       <- pattern
  out
}
