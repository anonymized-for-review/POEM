#' Run the power study under several mediation patterns at once
#'
#' A convenience wrapper around [pe_power_curve()] that runs the size and
#' power study under more than one mediation pattern in a single call and
#' stacks the results, so a homogeneous and a contrasting curve (the two
#' panels of a figure in the manuscript come back
#' together. Each pattern is swept over the same signal grid.
#'
#' @param n,p Observations and candidate mediators per simulated data set.
#' @param outcome Outcome type: `"continuous"`, `"binary"`, or `"count"`.
#' @param patterns Character vector of mediation patterns to run. Default
#'   `c("homogeneous", "contrasting")`.
#' @param c1_grid,c2,n_rep,alpha,method,error_level,cores,seed Passed to
#'   [pe_power_curve()].
#'
#' @return A tidy `data.frame` (class `poem_tbl`) with a leading `pattern`
#'   column and the [pe_power_curve()] columns (`c1`, `rejection_hdmm`,
#'   `rejection_pe`, `n_valid`) for each pattern.
#'
#' @author Anonymous
#'
#' @seealso [pe_power_curve()] for a single pattern, [plot.poem_tbl()] to
#'   draw one pattern's curves.
#'
#' @family mediation simulation
#'
#' @examples
#' \donttest{
#' set.seed(113)
#' pe_simulation_study(n = 120, p = 50, outcome = "continuous",
#'                     c1_grid = c(0, 0.5, 1), n_rep = 20)
#' }
#'
#' @export
pe_simulation_study <- function(n, p,
                                outcome = c("continuous", "binary", "count"),
                                patterns = c("homogeneous", "contrasting"),
                                c1_grid = seq(0, 1, by = 0.25), c2 = 0.5,
                                n_rep = 100, alpha = 0.05,
                                method = c("Bonferroni", "BH", "BY"),
                                error_level = 0.05, cores = 1L, seed = NULL) {
  outcome <- match.arg(outcome)
  method <- match.arg(method)
  patterns <- match.arg(patterns, c("homogeneous", "contrasting",
                                    "heterogeneous"), several.ok = TRUE)

  # Seed once here (rather than per pattern) so the whole study is reproducible
  # and the patterns are not handed the same stream.
  if (!is.null(seed)) {
    if (exists(".Random.seed", envir = globalenv())) {
      old <- get(".Random.seed", envir = globalenv())
      on.exit(assign(".Random.seed", old, envir = globalenv()), add = TRUE)
    } else {
      on.exit(if (exists(".Random.seed", envir = globalenv()))
        rm(".Random.seed", envir = globalenv()), add = TRUE)
    }
    set.seed(seed)
  }

  parts <- lapply(patterns, function(pat) {
    pc <- pe_power_curve(n = n, p = p, outcome = outcome, pattern = pat,
                         c1_grid = c1_grid, c2 = c2, n_rep = n_rep,
                         alpha = alpha, method = method,
                         error_level = error_level, cores = cores)
    cbind(pattern = pat, as.data.frame(unclass(pc)), stringsAsFactors = FALSE)
  })
  out <- do.call(rbind, parts)
  rownames(out) <- NULL
  out <- .as_poem_tbl(out)
  attr(out, "outcome") <- outcome
  attr(out, "n") <- n
  attr(out, "p") <- p
  attr(out, "n_rep") <- n_rep
  attr(out, "alpha") <- alpha
  out
}
