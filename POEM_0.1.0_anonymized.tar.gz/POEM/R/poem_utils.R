# Internal utilities shared by the POEM testing and simulation functions.
# None are exported. They concentrate the argument coercion, validation, and
# preprocessing that every pe_mediation_*() worker needs, so the workers
# differ only in the parts that are genuinely family-specific (the penalized
# fit and the Wald inference). The prior PEmediation package repeated this
# logic in each worker; centralizing it here removes that duplication and
# gives one place to test the input contract.

# Coerce X / M / Z to a numeric double matrix. A bare numeric vector becomes a
# one-column matrix (the q = 1 single-exposure case, which is the common one),
# a data.frame is matricized, and storage mode is forced to double so the
# downstream linear algebra never silently promotes from integer. NULL passes
# through as NULL so an absent confounder matrix Z stays absent.
#' @keywords internal
#' @noRd
.as_numeric_matrix <- function(x, name) {
  if (is.null(x)) return(NULL)
  if (is.vector(x) && !is.list(x)) x <- matrix(x, ncol = 1L)
  if (!is.matrix(x) && !is.data.frame(x))
    stop(sprintf("`%s` must be a numeric matrix, data.frame, or numeric vector.",
                 name), call. = FALSE)
  x <- as.matrix(x)
  if (!is.numeric(x))
    stop(sprintf("`%s` must be numeric.", name), call. = FALSE)
  storage.mode(x) <- "double"
  x
}

# Coerce the outcome Y to a numeric vector. A one-column matrix is flattened
# (a convenience, since Y is naturally a column), anything list-like is
# rejected, and the result is cast to double.
#' @keywords internal
#' @noRd
.as_numeric_vector <- function(x, name) {
  if (is.matrix(x) && ncol(x) == 1L) x <- as.vector(x)
  if (!is.atomic(x) || is.list(x))
    stop(sprintf("`%s` must be a numeric vector.", name), call. = FALSE)
  as.numeric(x)
}

# The tuning-parameter grid must be a non-empty vector of strictly positive,
# finite values: each entry is a candidate lambda for the penalized fit, and a
# nonpositive or non-finite lambda is not a valid penalty level.
#' @keywords internal
#' @noRd
.validate_lambda_grid <- function(x, name) {
  if (!is.numeric(x) || length(x) == 0L || any(!is.finite(x)) || any(x <= 0))
    stop(sprintf("`%s` must be a non-empty numeric vector with all elements > 0.",
                 name), call. = FALSE)
  invisible(TRUE)
}

# The target error rate for the mediator-screening step (FWER for Bonferroni,
# FDR for BH / BY) must be a single number strictly inside (0, 1): 0 would
# screen out every mediator and 1 would screen out none, and neither endpoint
# is a meaningful target rate.
#' @keywords internal
#' @noRd
.validate_error_level <- function(x) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x) || x <= 0 || x >= 1)
    stop("`error_level` must be a single number in (0, 1).", call. = FALSE)
  invisible(TRUE)
}

# The confidence level for the total-indirect-effect interval must be a single
# number strictly inside (0, 1).
#' @keywords internal
#' @noRd
.validate_conf_level <- function(x) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x) || x <= 0 || x >= 1)
    stop("`conf_level` must be a single number in (0, 1).", call. = FALSE)
  invisible(TRUE)
}

# Shared structural validation of (X, Y, M, Z): conforming row counts, a
# full-rank unpenalized design [X, Z] (the Wald inference inverts cross
# products of this block, so a collinear column makes the variance estimate
# singular), and no constant mediator columns (a zero-variance mediator cannot
# carry a signal and breaks standardization). Returns the coerced pieces plus
# n, q, and s = ncol(Z). Y-type checks (continuous vs 0/1 vs count) are left to
# the family worker, since only it knows the outcome model.
#' @keywords internal
#' @noRd
.pe_validate_inputs <- function(X, Y, M, Z, drop_constant = FALSE) {
  X <- .as_numeric_matrix(X, "X")
  M <- .as_numeric_matrix(M, "M")
  Y <- .as_numeric_vector(Y, "Y")
  n <- length(Y)

  if (nrow(X) != n)
    stop("`X` must have the same number of rows as the length of `Y`.",
         call. = FALSE)
  if (nrow(M) != n)
    stop("`M` must have the same number of rows as the length of `Y`.",
         call. = FALSE)

  if (!is.null(Z)) {
    Z <- .as_numeric_matrix(Z, "Z")
    if (nrow(Z) != n)
      stop("`Z` must have the same number of rows as the length of `Y`.",
           call. = FALSE)
  }

  # The unpenalized design [X, Z] must be full column rank. The mediation
  # inference inverts cross products formed from these columns; a rank
  # deficiency (a duplicated or collinear covariate) would make those
  # inversions fail or return garbage, so we stop early with a clear message.
  W <- if (is.null(Z)) X else cbind(X, Z)
  if (qr(W)$rank < ncol(W))
    stop("The design matrix formed by `X` and `Z` is singular (collinear ",
         "columns). Please remove redundant variables.", call. = FALSE)

  # A mediator with zero variance carries no information and cannot be
  # standardized (its standard deviation is zero). By default this is an error;
  # with drop_constant = TRUE the constant columns are dropped (with a warning)
  # and `kept` records the surviving columns' positions in the original `M`, so
  # the caller can map reported mediator indices back to the user's columns.
  m_var <- apply(M, 2L, stats::var)
  kept <- NULL
  if (any(m_var == 0)) {
    const_cols <- which(m_var == 0)
    if (!isTRUE(drop_constant))
      stop("The mediator matrix `M` contains constant (zero-variance) ",
           "columns: ", paste(const_cols, collapse = ", "),
           ". Remove them, or pass `drop_constant = TRUE` to drop them ",
           "automatically.", call. = FALSE)
    if (length(const_cols) >= ncol(M))
      stop("Every column of the mediator matrix `M` is constant ",
           "(zero variance); there is nothing to test.", call. = FALSE)
    warning(length(const_cols), " constant (zero-variance) mediator column",
            if (length(const_cols) > 1L) "s" else "", " dropped: ",
            paste(const_cols, collapse = ", "), ".", call. = FALSE)
    kept <- which(m_var != 0)
    M <- M[, kept, drop = FALSE]
  }

  list(X = X, Y = Y, M = M, Z = Z, n = n, q = ncol(X),
       s = if (is.null(Z)) 0L else ncol(Z), kept = kept)
}

# Standardize covariates and mediators (and center the continuous outcome)
# before fitting, matching the preprocessing described in the manuscript: the
# penalty treats every mediator coefficient on a common scale, which requires
# the columns to share a scale. X, M, and Z are standardized to mean 0 and
# unit variance. For a continuous (Gaussian) outcome Y is centered so the
# intercept can be dropped from the linear model; for binary and count
# outcomes Y is a 0/1 or count response and is left untouched, since centering
# would destroy its meaning under the link.
#' @keywords internal
#' @noRd
.pe_scale_data <- function(X, Y, M, Z, center_y) {
  X <- base::scale(X)
  M <- base::scale(M)
  if (!is.null(Z)) Z <- base::scale(Z)
  if (center_y) Y <- Y - mean(Y)
  list(X = X, Y = Y, M = M, Z = Z)
}

# The global test rejects when the test statistic exceeds the upper-alpha
# quantile of a chi-square with q degrees of freedom (q = number of
# exposures), so the p-value is the chi-square upper-tail probability. Both the
# benchmark Wald statistic S_n and the power-enhanced statistic M_PE use this
# same reference distribution under the global null (Theorems on the limiting
# null distribution). lower.tail = FALSE is used rather than 1 - pchisq() so
# the far upper tail (p-values near machine zero, which the PE statistic
# routinely produces) keeps its precision instead of cancelling to 0.
#' @keywords internal
#' @noRd
.pe_chisq_pvalue <- function(stat, df) {
  stats::pchisq(stat, df = df, lower.tail = FALSE)
}

# Optionally-parallel lapply used by the Monte Carlo and multi-group routines.
# On Unix with cores > 1 it forks via parallel::mclapply (parallel is a base
# package, so no extra dependency); otherwise it is an ordinary lapply. Callers
# that need reproducibility under forking set RNGkind("L'Ecuyer-CMRG") and a
# seed first, which gives parallel-safe streams. Not exported.
#' @keywords internal
#' @noRd
.pe_lapply <- function(X, FUN, cores = 1L) {
  if (cores > 1L && .Platform$OS.type == "unix")
    parallel::mclapply(X, FUN, mc.cores = cores)
  else
    lapply(X, FUN)
}
