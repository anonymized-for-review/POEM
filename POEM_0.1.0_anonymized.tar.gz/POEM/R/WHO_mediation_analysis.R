# Fit one subgroup with the manuscript's exact preprocessing: standardize the
# exposure and mediators, center the outcome, and leave the confounder
# indicators UNSCALED (so the benchmark Wald test follows the manuscript, which
# does not scale the region/income/year covariates). Returns one summary row.
# Not exported.
#' @keywords internal
#' @noRd
.WHO_fit_group <- function(grouping, group, des, lambda_grid, error_level,
                           full_table = FALSE) {
  # Some indicators are constant within a small region/income cell; drop them
  # (they carry no signal and break standardization) and keep the surviving
  # indicator codes so the reported active mediators map back correctly.
  keep <- which(apply(des$M, 2L, stats::sd) > 0)
  M <- des$M[, keep, drop = FALSE]
  ind <- des$indicators[keep]
  fit <- pe_mediation_linear(
    scale(des$X), des$Y - mean(des$Y), scale(M), Z = des$Z,
    scale = FALSE, error_level = error_level,
    report_all_methods = full_table,
    lambda_grid = lambda_grid, lambda_grid_reduced = lambda_grid)
  pval_hdmm <- fit$value[fit$term == "pval_hdmm"]
  codes <- function(idx) if (length(idx))
    paste(ind[idx], collapse = ", ") else "none"

  if (!full_table) {
    active_idx <- attr(fit, "active_mediators")
    return(data.frame(
      grouping = grouping, group = group, n_countries = des$n_countries,
      pval_hdmm = pval_hdmm,
      pval_pe   = fit$value[fit$term == "pval_pe"],
      n_active  = length(active_idx),
      active_mediators = codes(active_idx),
      stringsAsFactors = FALSE))
  }

  # full_table: report the PE p-value and the active mediator codes under each
  # multiplicity method (Bonferroni / BH / BY), as the manuscript's extended
  # data-analysis tables do.
  pbm <- attr(fit, "pe_by_method")
  sbm <- attr(fit, "selection_by_method")
  meth_key <- c(Bonferroni = "bonferroni", BH = "bh", BY = "by")
  row <- data.frame(grouping = grouping, group = group,
                    n_countries = des$n_countries,
                    pval_hdmm = pval_hdmm, stringsAsFactors = FALSE)
  for (m in names(meth_key)) {
    k <- meth_key[[m]]
    row[[paste0("pval_pe_", k)]] <-
      if (!is.null(pbm)) pbm$pval_pe[match(m, pbm$method)] else NA_real_
    idx <- if (!is.null(sbm)) sbm[[m]] else integer(0)
    row[[paste0("active_", k)]] <- codes(idx)
  }
  row
}

#' Reproduce the manuscript's empirical mediation analysis
#'
#' Runs the manuscript's real-data analysis for one health outcome across the
#' groupings it reports: a global model using all WHO members, then
#' separate models within each WHO region, within each World Bank income
#' group, and (optionally) within each region-by-income cell. For every
#' grouping it reports the benchmark Wald test and the power-enhanced test
#' on the total indirect effect of health expenditure, together with the
#' individual mediators the PE test identifies as active. This reproduces
#' the structure of the manuscript's data-analysis
#' tables (for example its Table for infant mortality) from the shipped
#' [WHO_health_mediation] data.
#'
#' The output is the package's \strong{benchmark fit}: applied to the
#' benchmark [WHO_health_mediation] data with the default settings, it
#' returns the active mediators reported in the source manuscript, and the
#' package's test suite checks those values, so the fit
#' serves as a fixed reference point for the method.
#'
#' @details
#' Each subgroup is fit with the manuscript's preprocessing: the exposure and
#' the 57 mediators are standardized, the outcome is centered, and the
#' confounder indicators (region, income, year) are left unscaled. Groups
#' with too few complete observations (some region-by-income cells are
#' empty or nearly so) are skipped. Because every cell fits a penalized
#' model over a grid of tuning parameters, a full run with all groupings
#' fits dozens of models and can take a few minutes; start with the
#' default groupings, or a single outcome, before scaling up.
#'
#' Exact p-values depend on modeling choices that the manuscript fix
#' (the tuning-parameter grid, the unscaled confounders); the active
#' mediators the PE test identifies are the stable, substantive output and
#' reproduce the manuscript's findings (for example, general government
#' expenditure as a percent of GDP, `gge_gdp`, for the global
#' infant-mortality model).
#'
#' @param outcome Which health outcome to analyze: `"imr"`, `"u5mr"`,
#'   `"leb"`, `"lbw"`, or `"pou"`. See [WHO_health_mediation].
#' @param groupings Character vector of groupings to run, any of
#'   `"global"`, `"region"`, `"income"`, and `"region_income"`. Default
#'   `c("global", "region", "income")` (the region-by-income cells are the
#'   slowest and are opt-in).
#' @param error_level Target family-wise error rate for the
#'   mediator-screening step. Default 0.05, as in the manuscript.
#' @param lambda_grid Tuning-parameter grid for the subgroup penalized fits
#'   (regional, income, and region-by-income models). Default
#'   `seq(0.1, 10, length.out = 100)`, matching the manuscript.
#' @param lambda_grid_global Tuning-parameter grid for the global (all-country)
#'   model only. Default `seq(0.1, 5, length.out = 100)`, matching the
#'   manuscript's narrower range for the global fit.
#' @param data The source data. Defaults to [WHO_health_mediation].
#' @param cores Number of CPU cores; values above 1 fit the subgroups in
#'   parallel via the base \pkg{parallel} package (Unix only). Default 1.
#' @param verbose Logical; if `TRUE`, print each group as it is fit.
#'   Default `FALSE`.
#' @param full_table Logical; if `TRUE`, return the manuscript's
#'   \emph{extended} table layout, with the power-enhanced p-value and the
#'   active mediator codes reported separately under each multiplicity
#'   method (Bonferroni for FWER, BH and BY for FDR) instead of a single
#'   primary method. Default `FALSE`.
#'
#' @return A `data.frame` with one row per fitted subgroup. With
#'   `full_table = FALSE` (the default) the columns are `grouping`
#'   (global / region / income / region_income), `group` (the specific
#'   group, for example `AFR` or `Low`), `n_countries` (number of countries),
#'   `pval_hdmm` and `pval_pe` (the benchmark and power-enhanced p-values
#'   for the total indirect effect), `n_active` (number of active mediators
#'   identified), and `active_mediators` (their codes, or `"none"`). With
#'   `full_table = TRUE` the single `pval_pe`/`n_active`/`active_mediators`
#'   columns are replaced by `pval_pe_bonferroni`, `pval_pe_bh`,
#'   `pval_pe_by` and the matching `active_bonferroni`, `active_bh`,
#'   `active_by` code columns. The result is a `poem_tbl`; call
#'   [summary()][summary.poem_tbl] on it for a cross-group digest of where
#'   the power-enhanced test detects mediation the benchmark misses.
#'
#' @author Anonymous
#'
#' @references
#' Anonymous (minor revision). Power Enhancement in
#' High-Dimensional Heterogeneous Mediation Analysis. \emph{Journal of the
#' American Statistical Association}.
#'
#' @seealso [WHO_mediation_design()] for a single design,
#'   [WHO_health_mediation] for the data, [pe_mediation()] for the test.
#'
#' @family WHO mediation data
#'
#' @examples
#' \donttest{
#' # The global and regional infant-mortality models (a minute or two).
#' WHO_mediation_analysis("imr", groupings = c("global", "region"))
#' }
#'
#' @export
WHO_mediation_analysis <- function(outcome = c("imr", "u5mr", "leb",
                                               "lbw", "pou"),
                                   groupings = c("global", "region", "income"),
                                   error_level = 0.05,
                                   lambda_grid = seq(0.1, 10, length.out = 100),
                                   lambda_grid_global = seq(0.1, 5,
                                                            length.out = 100),
                                   data = WHO_health_mediation,
                                   cores = 1L, verbose = FALSE,
                                   full_table = FALSE) {
  outcome <- match.arg(outcome)
  groupings <- match.arg(groupings,
                         c("global", "region", "income", "region_income"),
                         several.ok = TRUE)

  regions <- c("AFR", "AMR", "EMR", "EUR", "SEAR", "WPR")
  incomes <- c("Low", "Lower-middle", "Upper-middle", "High")

  # Build the (grouping, group, region-filter, income-filter) work list from
  # the requested groupings.
  jobs <- list()
  if ("global" %in% groupings)
    jobs <- c(jobs, list(list(g = "global", lab = "ALL", reg = NULL, inc = NULL)))
  if ("region" %in% groupings)
    jobs <- c(jobs, lapply(regions,
              function(r) list(g = "region", lab = r, reg = r, inc = NULL)))
  if ("income" %in% groupings)
    jobs <- c(jobs, lapply(incomes,
              function(i) list(g = "income", lab = i, reg = NULL, inc = i)))
  if ("region_income" %in% groupings)
    jobs <- c(jobs, unlist(lapply(regions, function(r) lapply(incomes,
              function(i) list(g = "region_income", lab = paste(r, i, sep = "-"),
                               reg = r, inc = i))), recursive = FALSE))

  # Fit one grouping cell, returning a one-row summary. Cells with too few
  # observations (WHO_mediation_design() errors) or a failed fit are recorded as
  # NA rather than aborting the whole run.
  fit_job <- function(job) {
    if (verbose) message("Fitting ", outcome, " / ", job$lab, " ...")
    na_row <- function(n_countries) {
      if (!full_table)
        return(data.frame(
          grouping = job$g, group = job$lab, n_countries = n_countries,
          pval_hdmm = NA_real_, pval_pe = NA_real_, n_active = NA_integer_,
          active_mediators = NA_character_, stringsAsFactors = FALSE))
      data.frame(
        grouping = job$g, group = job$lab, n_countries = n_countries,
        pval_hdmm = NA_real_,
        pval_pe_bonferroni = NA_real_, active_bonferroni = NA_character_,
        pval_pe_bh = NA_real_, active_bh = NA_character_,
        pval_pe_by = NA_real_, active_by = NA_character_,
        stringsAsFactors = FALSE)
    }
    des <- tryCatch(
      WHO_mediation_design(outcome, region = job$reg, income = job$inc,
                           data = data),
      error = function(e) NULL)
    if (is.null(des)) return(na_row(NA_integer_))
    grid <- if (job$g == "global") lambda_grid_global else lambda_grid
    res <- tryCatch(
      .WHO_fit_group(job$g, job$lab, des, grid, error_level,
                     full_table = full_table),
      error = function(e) NULL)
    if (is.null(res)) res <- na_row(des$n_countries)
    res
  }
  rows <- .pe_lapply(jobs, fit_job, cores = cores)

  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  # Return the package's general poem_tbl so summary() gives the cross-group
  # benchmark-vs-PE digest; it still behaves as an ordinary data.frame.
  out <- .as_poem_tbl(out)
  attr(out, "outcome") <- outcome
  attr(out, "full_table") <- full_table
  out
}
