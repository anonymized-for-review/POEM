#' Monte Carlo size and power curve for the PE mediation tests
#'
#' Reproduces the manuscript's simulation studies: for each value of the
#' signal-strength scale \eqn{c_1} on a grid, it simulates many data sets,
#' applies both the benchmark Wald test and the power-enhanced test, and
#' returns their empirical rejection rates. At \eqn{c_1 = 0} (the global
#' null of no mediation) the rejection rate estimates the Type I error
#' rate; at nonzero \eqn{c_1} it estimates power. The headline finding is
#' visible directly in the table: under a contrasting pattern the
#' benchmark test stays near its nominal size as \eqn{|c_1|} grows while
#' the power-enhanced test climbs toward one.
#'
#' @param n,p Number of observations and candidate mediators per data set.
#' @param outcome Outcome type passed to [simulate_mediation_data()]:
#'   `"continuous"`, `"binary"`, or `"count"`.
#' @param pattern Mediation pattern: `"homogeneous"` or `"contrasting"`
#'   (`"heterogeneous"` is a synonym for `"contrasting"`).
#' @param c1_grid Numeric vector of signal-strength scales to sweep.
#'   Default `seq(0, 1, by = 0.25)`. Include 0 to estimate the Type I
#'   error rate; the manuscript also uses negative values.
#' @param c2 Direct effect used in the simulation. Default 0.5.
#' @param n_rep Number of Monte Carlo replications per grid point. Default
#'   100. The article uses 1000.
#' @param alpha Significance level for the global test. A replication
#'   counts as a rejection when its p-value is at most `alpha`. Default
#'   0.05.
#' @param method,error_level Passed to [pe_mediation()]: the multiplicity
#'   method and target error rate for the mediator-screening step.
#' @param outcome_args A list of further arguments forwarded to
#'   [simulate_mediation_data()] (for example `rho`, `q`, `d`, `tau`,
#'   `alpha_m`). Default empty.
#' @param cores Number of CPU cores for the Monte Carlo replications.
#'   Values above 1 fork via the base \pkg{parallel} package (Unix only).
#'   With parallel cores, reproducibility uses parallel-safe streams, so a
#'   seeded parallel run is reproducible across runs at the same `cores` but
#'   need not match a serial run. Default 1.
#' @param seed Optional integer seed, set locally with the caller's random
#'   number generator state restored on exit.
#' @param progress Logical; if `TRUE`, print a line per grid point as it
#'   completes. Default `FALSE`.
#'
#' @return A tidy `data.frame` of class `poem_tbl` with one row per grid
#'   point and columns `c1`, `rejection_hdmm`, and `rejection_pe` (the
#'   empirical rejection rates of the benchmark and power-enhanced tests),
#'   and `n_valid` (replications that fit successfully). The simulation
#'   settings are recorded in attributes.
#'
#' @author Anonymous
#'
#' @seealso [pe_mediation()], [simulate_mediation_data()].
#'
#' @family mediation simulation
#'
#' @examples
#' \donttest{
#' # A small, fast sweep. Raise n, p, and n_rep toward the manuscript's
#' # n = 300, p = 500, n_rep = 1000 for a publication-scale study.
#' set.seed(113)
#' pe_power_curve(n = 120, p = 60, outcome = "continuous",
#'                pattern = "contrasting", c1_grid = c(0, 0.5, 1),
#'                n_rep = 20)
#' }
#'
#' @export
pe_power_curve <- function(n, p,
                           outcome = c("continuous", "binary", "count"),
                           pattern = c("homogeneous", "contrasting",
                                       "heterogeneous"),
                           c1_grid = seq(0, 1, by = 0.25), c2 = 0.5,
                           n_rep = 100, alpha = 0.05,
                           method = c("Bonferroni", "BH", "BY"),
                           error_level = 0.05, outcome_args = list(),
                           cores = 1L, seed = NULL, progress = FALSE) {
  outcome <- match.arg(outcome)
  pattern <- match.arg(pattern)
  method <- match.arg(method)
  if (!is.numeric(alpha) || length(alpha) != 1L || alpha <= 0 || alpha >= 1)
    stop("`alpha` must be a single number in (0, 1).", call. = FALSE)

  if (!is.null(seed)) {
    if (exists(".Random.seed", envir = globalenv())) {
      old <- get(".Random.seed", envir = globalenv())
      on.exit(assign(".Random.seed", old, envir = globalenv()), add = TRUE)
    } else {
      on.exit(if (exists(".Random.seed", envir = globalenv()))
        rm(".Random.seed", envir = globalenv()), add = TRUE)
    }
    set.seed(seed)
  }
  if (cores > 1L) {
    old_kind <- RNGkind("L'Ecuyer-CMRG")
    on.exit(do.call(RNGkind, as.list(old_kind)), add = TRUE)
  }

  reject_hdmm <- numeric(length(c1_grid))
  reject_pe   <- numeric(length(c1_grid))
  n_valid     <- numeric(length(c1_grid))

  for (g in seq_along(c1_grid)) {
    c1 <- c1_grid[g]
    # One replication: simulate, fit both tests, return their two p-values. A
    # fit that errors (a near-singular draw, say) returns NA and is dropped from
    # that grid point's denominator rather than aborting the sweep.
    one_rep <- function(r) {
      dat <- do.call(simulate_mediation_data,
                     c(list(n = n, p = p, outcome = outcome, pattern = pattern,
                            c1 = c1, c2 = c2), outcome_args))
      fit <- tryCatch(
        pe_mediation(dat$X, dat$Y, dat$M, Z = dat$Z, outcome = outcome,
                     method = method, error_level = error_level),
        error = function(e) NULL)
      if (is.null(fit)) return(c(NA_real_, NA_real_))
      c(fit$value[fit$term == "pval_hdmm"], fit$value[fit$term == "pval_pe"])
    }
    pmat <- do.call(rbind, .pe_lapply(seq_len(n_rep), one_rep, cores = cores))
    p_hdmm <- pmat[, 1]; p_pe <- pmat[, 2]
    ok <- !is.na(p_hdmm) & !is.na(p_pe)
    n_valid[g]     <- sum(ok)
    reject_hdmm[g] <- mean(p_hdmm[ok] <= alpha)
    reject_pe[g]   <- mean(p_pe[ok] <= alpha)
    if (progress)
      message(sprintf("c1 = %.3g: reject HDMM = %.3f, PE = %.3f (%d/%d valid)",
                      c1, reject_hdmm[g], reject_pe[g], n_valid[g], n_rep))
  }

  out <- data.frame(c1 = c1_grid, rejection_hdmm = reject_hdmm,
                    rejection_pe = reject_pe, n_valid = n_valid,
                    stringsAsFactors = FALSE)
  out <- .as_poem_tbl(out)
  attr(out, "outcome") <- outcome
  attr(out, "pattern") <- pattern
  attr(out, "n")       <- n
  attr(out, "p")       <- p
  attr(out, "n_rep")   <- n_rep
  attr(out, "alpha")   <- alpha
  out
}
