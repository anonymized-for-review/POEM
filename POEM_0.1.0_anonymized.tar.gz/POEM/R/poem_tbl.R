#' Tidy printing for POEM result tables
#'
#' Every estimation and testing function in \pkg{POEM} returns a tidy
#' \code{data.frame} with a \code{term} column and one or more numeric
#' columns. A single numeric column routinely holds quantities on very
#' different scales: a whole-number count of mediators next to a
#' chi-square statistic in the hundreds next to a p-value of
#' \eqn{10^{-12}}. The base \code{\link[base]{print.data.frame}} method
#' formats a whole column with one common format, which forces either a
#' wall of trailing zeros or a slide into scientific notation. The
#' \code{poem_tbl} class supplies \code{print} and \code{format} methods
#' that format each value on its own terms: whole numbers (counts,
#' sample sizes, mediator indices) print without a decimal part, other
#' values print to a few significant figures, and p-values print to a
#' fixed number of decimal places with a \dQuote{< 0.0001} floor.
#'
#' The stored numeric values are never rounded. Only the display
#' changes, so any arithmetic you do on the returned object (a
#' confidence interval width, a further calculation) uses full
#' precision. To see more digits, raise \code{digits} or read the column
#' directly with \code{x$value}.
#'
#' This mirrors the display convention of the \pkg{DMAR} package, whose
#' house style \pkg{POEM} follows.
#'
#' @param x A \code{poem_tbl} object (a tidy \code{data.frame} returned
#'   by a POEM function).
#' @param digits Number of significant figures for non-integer values.
#'   Defaults to \code{getOption("poem.digits", 4L)}.
#' @param digits_p Number of decimal places for p-values. Defaults to 4.
#'   A p-value below \code{10^(-digits_p)} prints as \dQuote{< 0.0001}.
#' @param ... Additional arguments passed to
#'   \code{\link[base]{print.data.frame}}.
#'
#' @return \code{print.poem_tbl} returns \code{x} invisibly.
#'   \code{format.poem_tbl} returns a \code{data.frame} whose numeric
#'   columns have been formatted to character for display.
#'
#' @author Anonymous
#'
#' @examples
#' set.seed(113)
#' d <- simulate_mediation_data(n = 120, p = 60, pattern = "contrasting",
#'                              outcome = "continuous")
#' fit <- pe_mediation(d$X, d$Y, d$M, outcome = "continuous")
#' fit                       # rounded for reading
#' fit$value[fit$term == "pval_pe"]   # full precision underneath
#'
#' @name poem_tbl
NULL

# Element-wise display formatter shared by format.poem_tbl / print.poem_tbl.
# A finite value that equals its own rounding (a whole number, such as a
# count of mediators or a sample size) prints with no decimal part; any
# other finite value prints to `digits` significant figures, letting base R
# choose fixed versus scientific notation per value (so a chi-square of 412.7
# reads plainly while a tiny variance reads as 1.2e-05). The whole-number
# branch is capped at 1e15 because beyond that doubles cannot represent
# integers exactly and "x == round(x)" stops being meaningful. Not exported.
.format_poem_value <- function(v, digits = 4L) {
  vapply(v, function(x) {
    if (is.na(x)) return(NA_character_)
    if (is.finite(x) && x == round(x) && abs(x) < 1e15)
      return(format(x, scientific = FALSE, trim = TRUE))
    format(signif(x, digits), digits = digits, trim = TRUE)
  }, character(1L))
}

# Fixed-decimal p-value formatter. p-values read best at a fixed number of
# decimal places (the convention is four), never in scientific notation. A
# value below the smallest representable magnitude (10^(-digits_p)) prints as
# "< 0.0001" rather than rounding to "0.0000", which would misread as an exact
# zero. The PE tests can return p-values near machine zero (the chi-square
# upper tail at a statistic in the hundreds), so the floor matters here. Not
# exported.
.format_poem_pvalue <- function(p, digits_p = 4L) {
  thresh <- 10^(-digits_p)
  floor_label <- paste0("< ", formatC(thresh, format = "f", digits = digits_p))
  vapply(p, function(x) {
    if (is.na(x)) return(NA_character_)
    if (x < thresh) return(floor_label)
    formatC(x, format = "f", digits = digits_p)
  }, character(1L))
}

# Tag a tidy result table as a poem_tbl so it prints via print.poem_tbl. Every
# tidy-returning POEM function routes its result through this helper just
# before returning it. `p_terms`, when supplied, names the rows of the long
# `value` column that hold p-values (so the format method gives them fixed
# decimals); a wide table with a literal `p_value` column needs no p_terms, as
# the format method finds that column by name. The poem_tbl class is inserted
# just before `data.frame`, after any leading tidy/glance subclass, so the
# subclass keeps dispatching its own methods while print falls through here.
# Idempotent. Not exported.
.as_poem_tbl <- function(out, p_terms = NULL) {
  if (!is.null(p_terms)) attr(out, "p_terms") <- p_terms
  cls <- class(out)
  if (!("poem_tbl" %in% cls))
    class(out) <- c(setdiff(cls, "data.frame"), "poem_tbl", "data.frame")
  out
}

#' @rdname poem_tbl
#' @export
format.poem_tbl <- function(x, digits = getOption("poem.digits", 4L),
                            digits_p = 4L, ...) {
  raw <- x
  class(raw) <- "data.frame"
  out <- raw
  num <- vapply(out, is.numeric, logical(1L))
  out[num] <- lapply(out[num], .format_poem_value, digits = digits)

  # The "primary" numeric column carries the per-term quantities in a long
  # table: `value`. The p_terms attribute names rows of this column whose
  # quantity is a p-value and so should print to fixed decimals.
  primary <- intersect("value", names(out)[num])
  primary <- if (length(primary)) primary[1L] else NA_character_

  # A dedicated p-value column in a wide table is detected by name.
  for (nm in intersect(c("p_value", "p.value"), names(out)[num]))
    out[[nm]] <- .format_poem_pvalue(raw[[nm]], digits_p = digits_p)

  # Named rows of the long-format `value` column are detected via p_terms.
  p_terms <- attr(x, "p_terms")
  if (!is.null(p_terms) && "term" %in% names(out) && !is.na(primary)) {
    idx <- raw$term %in% p_terms
    out[[primary]][idx] <- .format_poem_pvalue(raw[[primary]][idx],
                                               digits_p = digits_p)
  }
  out
}

#' @rdname poem_tbl
#' @export
print.poem_tbl <- function(x, digits = getOption("poem.digits", 4L),
                           digits_p = 4L, ...) {
  disp <- format(x, digits = digits, digits_p = digits_p)
  # row.names / right travel through `...` so a caller can override them, but
  # default to the tidy look (no row numbers, left-aligned).
  dots <- list(...)
  if (is.null(dots[["row.names"]])) dots[["row.names"]] <- FALSE
  if (is.null(dots[["right"]]))     dots[["right"]]     <- FALSE
  do.call(print.data.frame, c(list(disp), dots))

  # A short, human-readable footer naming the outcome model and any active
  # mediators the test identified. The numbers are already in the table; the
  # footer just makes the headline reading effortless.
  outcome <- attr(x, "outcome")
  if (!is.null(outcome)) cat(sprintf("\nOutcome model: %s\n", outcome))
  active <- attr(x, "active_mediators")
  if (!is.null(active)) {
    if (length(active) == 0L) {
      cat("Active mediators identified: none\n")
    } else {
      cat(sprintf("Active mediators identified (%d): %s\n",
                  length(active), paste(active, collapse = ", ")))
    }
  }
  invisible(x)
}
