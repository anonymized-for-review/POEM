#' Monte Carlo study of individual-mediator identification (FWER / FDR)
#'
#' Evaluates how well the power-enhanced screen recovers the *individual*
#' active mediators, the experiment reported in the manuscript's supplement.
#' For each signal-strength scale \eqn{c_1} on a grid it simulates many data
#' sets, identifies the active set under each multiplicity method, and scores
#' those selections against the known truth, returning the empirical
#' family-wise error rate, false discovery rate, precision, and recall. This
#' complements [pe_power_curve()], which evaluates the *global* test rather
#' than which mediators are flagged.
#'
#' At \eqn{c_1 = 0} the exposure-on-mediator paths are all zero, so there are
#' no truly active mediators and any selection is a false positive; the
#' family-wise error rate column is then the probability of selecting any
#' mediator (the empirical FWER under the null). Recall is undefined when
#' there are no active mediators (at \eqn{c_1 = 0}) and is reported as `NA`
#' there; precision is `NA` for a replication that selects nothing and is
#' averaged over the replications that select at least one mediator.
#'
#' @param n,p Number of observations and candidate mediators per data set.
#' @param outcome Outcome type passed to [simulate_mediation_data()]:
#'   `"continuous"`, `"binary"`, or `"count"`.
#' @param pattern Mediation pattern: `"homogeneous"` or `"contrasting"`
#'   (`"heterogeneous"` is a synonym for `"contrasting"`).
#' @param c1_grid Numeric vector of signal-strength scales to sweep.
#'   Default `seq(0, 1, by = 0.25)`. Include 0 to estimate the null
#'   family-wise error rate.
#' @param c2 Direct effect used in the simulation. Default 0.5.
#' @param n_rep Number of Monte Carlo replications per grid point. Default
#'   200. The manuscript uses 1000.
#' @param methods Multiplicity methods to evaluate, any of `"Bonferroni"`
#'   (family-wise error rate), `"BH"`, and `"BY"` (false discovery rate).
#'   Default all three.
#' @param error_level Target error rate for the mediator-screening step
#'   (the FWER level for Bonferroni, the FDR level for BH and BY). Default
#'   0.05.
#' @param outcome_args A list of further arguments forwarded to
#'   [simulate_mediation_data()] (for example `rho`, `q`, `d`, `tau`,
#'   `alpha_m`). Default empty.
#' @param cores Number of CPU cores for the replications. Values above 1
#'   fork via the base \pkg{parallel} package (Unix only); a seeded parallel
#'   run is reproducible across runs at the same `cores` but need not match a
#'   serial run. Default 1.
#' @param seed Optional integer seed, set locally with the caller's random
#'   number generator state restored on exit.
#' @param progress Logical; if `TRUE`, print a line per grid point. Default
#'   `FALSE`.
#'
#' @return A tidy `data.frame` of class `poem_tbl` with one row per
#'   (\eqn{c_1}, method) combination and columns `c1`, `method`, `fwer`
#'   (empirical family-wise error rate, the proportion of replications with
#'   at least one false positive), `fdr` (mean false discovery proportion),
#'   `precision`, `recall`, and `n_valid` (replications that fit
#'   successfully). The simulation settings are recorded in attributes.
#'
#' @author Anonymous
#'
#' @references
#' Anonymous (minor revision). Power Enhancement in
#' High-Dimensional Heterogeneous Mediation Analysis. \emph{Journal of the
#' American Statistical Association}.
#'
#' @seealso [pe_power_curve()] for the global test, [pe_selection()] for the
#'   per-method active set of a single fit.
#'
#' @family mediation simulation
#'
#' @examples
#' \donttest{
#' # A small, fast study. Raise n, p, and n_rep toward the manuscript's
#' # settings for a publication-scale study.
#' set.seed(113)
#' pe_identification_study(n = 150, p = 60, outcome = "continuous",
#'                         pattern = "contrasting", c1_grid = c(0, 0.5, 1),
#'                         n_rep = 20)
#' }
#'
#' @export
pe_identification_study <- function(n, p,
                                    outcome = c("continuous", "binary",
                                                "count"),
                                    pattern = c("homogeneous", "contrasting",
                                                "heterogeneous"),
                                    c1_grid = seq(0, 1, by = 0.25), c2 = 0.5,
                                    n_rep = 200,
                                    methods = c("Bonferroni", "BH", "BY"),
                                    error_level = 0.05, outcome_args = list(),
                                    cores = 1L, seed = NULL, progress = FALSE) {
  outcome <- match.arg(outcome)
  pattern <- match.arg(pattern)
  methods <- match.arg(methods, c("Bonferroni", "BH", "BY"), several.ok = TRUE)
  .validate_error_level(error_level)

  if (!is.null(seed)) {
    if (exists(".Random.seed", envir = globalenv())) {
      old <- get(".Random.seed", envir = globalenv())
      on.exit(assign(".Random.seed", old, envir = globalenv()), add = TRUE)
    } else {
      on.exit(if (exists(".Random.seed", envir = globalenv()))
        rm(".Random.seed", envir = globalenv()), add = TRUE)
    }
    set.seed(seed)
  }
  if (cores > 1L) {
    old_kind <- RNGkind("L'Ecuyer-CMRG")
    on.exit(do.call(RNGkind, as.list(old_kind)), add = TRUE)
  }

  # The active set selected under each method, for one fit. report_all_methods
  # populates selection_by_method; the empty-fit path leaves it NULL (no
  # mediator selected under any method).
  method_sets <- function(fit) {
    sbm <- attr(fit, "selection_by_method")
    if (is.null(sbm)) {
      act <- attr(fit, "active_mediators")
      sbm <- stats::setNames(rep(list(integer(0)), length(methods)), methods)
      prim <- attr(fit, "method")
      if (prim %in% methods) sbm[[prim]] <- act
    }
    sbm[methods]
  }

  res <- vector("list", length(c1_grid))
  for (g in seq_along(c1_grid)) {
    c1 <- c1_grid[g]
    # One replication: simulate, fit with all requested methods, and score each
    # method's selection against the known active set. A failed fit returns a
    # row of NAs flagged invalid and is dropped from the denominators.
    one_rep <- function(r) {
      dat <- do.call(simulate_mediation_data,
                     c(list(n = n, p = p, outcome = outcome, pattern = pattern,
                            c1 = c1, c2 = c2), outcome_args))
      truth <- dat$active_mediators
      fit <- tryCatch(
        pe_mediation(dat$X, dat$Y, dat$M, Z = dat$Z, outcome = outcome,
                     method = methods[1L], error_level = error_level,
                     report_all_methods = length(methods) > 1L),
        error = function(e) NULL)
      if (is.null(fit))
        return(data.frame(method = methods, any_fp = NA_real_, fdp = NA_real_,
                          precision = NA_real_, recall = NA_real_,
                          valid = FALSE, stringsAsFactors = FALSE))
      sets <- method_sets(fit)
      do.call(rbind, lapply(methods, function(m) {
        sel <- sets[[m]]
        tp <- length(intersect(sel, truth))
        fp <- length(setdiff(sel, truth))
        n_sel <- length(sel); n_tru <- length(truth)
        data.frame(
          method = m,
          any_fp = as.numeric(fp >= 1L),
          fdp = if (n_sel > 0L) fp / n_sel else 0,
          precision = if (n_sel > 0L) tp / n_sel else NA_real_,
          recall = if (n_tru > 0L) tp / n_tru else NA_real_,
          valid = TRUE, stringsAsFactors = FALSE)
      }))
    }
    reps <- do.call(rbind, .pe_lapply(seq_len(n_rep), one_rep, cores = cores))

    # Aggregate over the valid replications, per method.
    avg <- function(x) if (any(!is.na(x))) mean(x, na.rm = TRUE) else NA_real_
    rows <- lapply(methods, function(m) {
      sub <- reps[reps$method == m & reps$valid, , drop = FALSE]
      data.frame(c1 = c1, method = m,
                 fwer = avg(sub$any_fp), fdr = avg(sub$fdp),
                 precision = avg(sub$precision), recall = avg(sub$recall),
                 n_valid = nrow(sub), stringsAsFactors = FALSE)
    })
    res[[g]] <- do.call(rbind, rows)
    if (progress)
      message(sprintf("c1 = %.3g done (%d methods x %d reps)",
                      c1, length(methods), n_rep))
  }

  out <- do.call(rbind, res)
  rownames(out) <- NULL
  out <- .as_poem_tbl(out)
  attr(out, "outcome")     <- outcome
  attr(out, "pattern")     <- pattern
  attr(out, "n")           <- n
  attr(out, "p")           <- p
  attr(out, "n_rep")       <- n_rep
  attr(out, "error_level") <- error_level
  out
}
